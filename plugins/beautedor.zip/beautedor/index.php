<?php

/**
 * Plugin Name: Beauté d'or
 * Description: Specifics blocks for beauté d'or project
 * Version: 1.0.0
 * Author: Bewi
 *
 * @package beautedor
 */

defined( 'ABSPATH' ) || exit;

include 'info-block/index.php';
include 'scroll-to/index.php';
include 'flex-grid/index.php';
